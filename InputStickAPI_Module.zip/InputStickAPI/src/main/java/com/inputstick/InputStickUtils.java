package com.inputstick;

public class InputStickUtils {
    public static String getInfo() {
        return "InputStick API module loaded successfully.";
    }
}
